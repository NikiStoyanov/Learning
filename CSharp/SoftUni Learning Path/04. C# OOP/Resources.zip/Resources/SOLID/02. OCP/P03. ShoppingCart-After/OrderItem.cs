﻿namespace P03._ShoppingCart_After
{
    public class OrderItem
    {
        public string Sku { get; set; }

        public int Quantity { get; set; }
    }
}

﻿namespace P02._DrawingShape_Before
{
    using Contracts;

    class Rectangle : IShape
    {


    }
}

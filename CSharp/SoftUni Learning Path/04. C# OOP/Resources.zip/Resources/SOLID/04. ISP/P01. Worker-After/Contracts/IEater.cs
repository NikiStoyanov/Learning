﻿namespace P01._Worker_After.Contracts
{
    public interface IEater
    {
        void Eat();
    }
}

﻿namespace P02._Worker_After
{
    using Contracts;

    public class Worker : IWorker
    {
        public void Work()
        {
            // work
        }
    }
}

﻿namespace P01._DrawingShape_After.Contracts
{
    public interface IShape
    {
        double Area { get; }
    }
}

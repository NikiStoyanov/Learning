﻿namespace CarRentalSystem.Admin.Models.Statistics
{
    public class StatisticsOutputModel
    {
        public int TotalCarAds { get; set; }

        public int TotalRentedCars { get; set; }
    }
}

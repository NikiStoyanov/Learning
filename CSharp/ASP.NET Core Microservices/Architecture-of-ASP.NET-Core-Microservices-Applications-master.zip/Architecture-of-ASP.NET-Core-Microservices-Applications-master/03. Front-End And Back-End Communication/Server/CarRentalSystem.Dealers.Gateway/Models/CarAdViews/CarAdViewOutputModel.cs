﻿namespace CarRentalSystem.Dealers.Gateway.Models.CarAdViews
{
    public class CarAdViewOutputModel
    {
        public int CarAdId { get; set; }

        public int TotalViews { get; set; }
    }
}

﻿namespace CarRentalSystem.Dealers.Gateway.Services
{
    public class ServiceEndpoints
    {
        public string Statistics { get; private set; }

        public string Dealers { get; private set; }
    }
}

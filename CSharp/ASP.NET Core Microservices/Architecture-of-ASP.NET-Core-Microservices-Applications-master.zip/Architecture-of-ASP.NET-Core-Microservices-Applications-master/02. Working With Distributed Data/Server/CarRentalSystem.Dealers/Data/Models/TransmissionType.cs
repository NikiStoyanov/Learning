﻿namespace CarRentalSystem.Dealers.Data.Models
{
    public enum TransmissionType
    {
        Manual = 1,
        Automatic = 2
    }
}

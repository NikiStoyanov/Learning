﻿namespace CarRentalSystem.Statistics.Data.Models
{
    public class CarAdView
    {
        public int Id { get; set; }

        public int CarAdId { get; set; }

        public string UserId { get; set; }
    }
}

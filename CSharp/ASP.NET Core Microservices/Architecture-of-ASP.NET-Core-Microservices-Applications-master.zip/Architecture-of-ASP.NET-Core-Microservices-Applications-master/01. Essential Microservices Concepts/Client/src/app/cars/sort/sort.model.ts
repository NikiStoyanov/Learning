export interface Sort {
    sortBy: string;
    order: string;
}
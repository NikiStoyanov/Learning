export interface Profile {
    id?: number;
    name: string;
    phoneNumber: string;
    totalCarAds?: number;
}
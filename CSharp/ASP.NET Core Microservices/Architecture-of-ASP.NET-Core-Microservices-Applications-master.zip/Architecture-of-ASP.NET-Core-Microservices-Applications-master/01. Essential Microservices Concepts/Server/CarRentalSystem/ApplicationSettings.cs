﻿namespace CarRentalSystem
{
    public class ApplicationSettings
    {
        public string Secret { get; set; }
    }
}

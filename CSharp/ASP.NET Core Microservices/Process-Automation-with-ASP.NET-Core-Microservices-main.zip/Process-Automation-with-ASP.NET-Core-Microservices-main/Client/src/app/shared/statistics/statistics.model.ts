export interface Statistics {
    totalCarAds: number;
    totalRentedCars: number;
}
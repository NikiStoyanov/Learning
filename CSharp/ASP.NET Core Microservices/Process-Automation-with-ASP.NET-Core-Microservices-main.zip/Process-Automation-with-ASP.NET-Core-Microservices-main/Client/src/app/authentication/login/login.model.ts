export interface LoginFormModel {
    email: string;
    password: string;
}
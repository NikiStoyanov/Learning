export interface PasswordChange {
    currentPassword: string;
    newPassword: string;
}
export const environment = {
    production: true,
    identityApiUrl: 'http://35.188.60.251:5001/',
    dealersApiUrl: 'http://34.71.166.219:5002/',
    statisticsApiUrl: 'http://34.71.16.80:5003/',
    notificationsUrl: 'http://34.66.11.105:5004/'
  };
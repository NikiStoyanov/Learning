export const environment = {
  production: true,
  identityApiUrl: 'http://34.122.74.94:5001/',
  dealersApiUrl: 'http://35.184.122.109:5002/',
  statisticsApiUrl: 'http://35.223.2.95:5003/',
  notificationsUrl: 'http://35.202.99.212:5004/'
};

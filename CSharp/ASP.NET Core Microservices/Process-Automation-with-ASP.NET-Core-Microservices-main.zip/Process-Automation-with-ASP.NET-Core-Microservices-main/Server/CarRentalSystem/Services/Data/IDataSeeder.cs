﻿namespace CarRentalSystem.Services.Data
{
    public interface IDataSeeder
    {
        void SeedData();
    }
}

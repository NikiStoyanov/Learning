﻿namespace CarRentalSystem
{
    public class Constants
    {
        public const string AdministratorRoleName = "Administrator";
    }
}

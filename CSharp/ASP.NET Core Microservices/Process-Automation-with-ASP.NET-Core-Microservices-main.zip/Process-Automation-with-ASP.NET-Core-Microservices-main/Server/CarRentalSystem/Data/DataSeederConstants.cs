﻿namespace CarRentalSystem.Data
{
    public class DataSeederConstants
    {
        public const string DefaultUserId = "6be0140d-91db-46e3-adc0-bba8839239c6";
        public const string DefaultUserPassword = "coolcars12!";
    }
}

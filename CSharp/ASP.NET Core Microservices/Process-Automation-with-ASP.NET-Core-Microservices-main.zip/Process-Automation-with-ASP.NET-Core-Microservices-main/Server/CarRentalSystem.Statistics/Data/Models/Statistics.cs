﻿namespace CarRentalSystem.Statistics.Data.Models
{
    public class Statistics
    {
        public int Id { get; set; }

        public int TotalCarAds { get; set; }

        public int TotalRentedCars { get; set; }
    }
}

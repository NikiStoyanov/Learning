﻿namespace CarRentalSystem.Statistics.Models.CarAdViews
{
    public class CarAdViewOutputModel
    {
        public int CarAdId { get; set; }

        public int TotalViews { get; set; }
    }
}

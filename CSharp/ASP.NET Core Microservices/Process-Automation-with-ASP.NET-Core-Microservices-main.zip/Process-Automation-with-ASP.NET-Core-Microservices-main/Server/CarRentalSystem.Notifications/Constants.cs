﻿namespace CarRentalSystem.Notifications
{
    public class Constants
    {
        public const string AuthenticatedUsersGroup = "AuthenticatedUsers";

        public const string ReceiveNotificationEndpoint = "ReceiveNotification";
    }
}

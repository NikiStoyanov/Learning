﻿namespace CarRentalSystem.Notifications
{
    public class NotificationSettings
    {
        public string AllowedOrigins { get; private set; }
    }
}

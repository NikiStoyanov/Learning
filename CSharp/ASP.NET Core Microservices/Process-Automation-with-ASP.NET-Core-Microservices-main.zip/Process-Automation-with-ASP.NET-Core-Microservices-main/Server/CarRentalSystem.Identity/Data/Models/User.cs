﻿namespace CarRentalSystem.Identity.Data.Models
{
    using Microsoft.AspNetCore.Identity;

    public class User : IdentityUser
    {
    }
}

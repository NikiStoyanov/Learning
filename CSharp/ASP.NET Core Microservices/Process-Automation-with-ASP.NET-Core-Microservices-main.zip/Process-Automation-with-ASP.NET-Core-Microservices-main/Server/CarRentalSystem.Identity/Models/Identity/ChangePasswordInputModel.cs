﻿namespace CarRentalSystem.Identity.Models.Identity
{
    public class ChangePasswordInputModel
    {
        public string CurrentPassword { get; set; }

        public string NewPassword { get; set; }
    }
}

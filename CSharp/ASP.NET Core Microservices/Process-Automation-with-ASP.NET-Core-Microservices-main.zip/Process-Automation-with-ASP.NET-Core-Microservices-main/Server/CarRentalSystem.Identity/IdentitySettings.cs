﻿namespace CarRentalSystem.Identity
{
    public class IdentitySettings
    {
        public string AdminPassword { get; private set; }
    }
}

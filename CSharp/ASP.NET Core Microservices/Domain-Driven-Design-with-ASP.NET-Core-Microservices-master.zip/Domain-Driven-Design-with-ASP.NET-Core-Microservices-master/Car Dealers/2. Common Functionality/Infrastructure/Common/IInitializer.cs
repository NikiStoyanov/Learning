﻿namespace CarRentalSystem.Infrastructure.Common
{
    public interface IInitializer
    {
        void Initialize();
    }
}

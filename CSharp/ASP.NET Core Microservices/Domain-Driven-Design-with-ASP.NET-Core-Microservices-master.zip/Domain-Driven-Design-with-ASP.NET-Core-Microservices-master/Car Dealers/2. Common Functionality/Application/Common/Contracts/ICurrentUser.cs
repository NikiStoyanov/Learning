﻿namespace CarRentalSystem.Application.Common.Contracts
{
    public interface ICurrentUser
    {
        string UserId { get; }
    }
}

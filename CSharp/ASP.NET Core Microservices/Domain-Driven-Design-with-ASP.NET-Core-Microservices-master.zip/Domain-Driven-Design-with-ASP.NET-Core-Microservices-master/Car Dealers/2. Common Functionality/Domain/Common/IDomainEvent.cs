﻿namespace CarRentalSystem.Domain.Common
{
    public interface IDomainEvent
    {
    }
}

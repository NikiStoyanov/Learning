﻿namespace CarRentalSystem.Domain.Dealerships.Events.Dealers
{
    using Common;

    public class CarAdAddedEvent : IDomainEvent
    {
    }
}

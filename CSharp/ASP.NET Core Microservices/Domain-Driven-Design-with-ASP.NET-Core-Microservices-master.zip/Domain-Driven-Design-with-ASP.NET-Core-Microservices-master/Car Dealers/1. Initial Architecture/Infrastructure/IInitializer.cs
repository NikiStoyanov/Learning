﻿namespace CarRentalSystem.Infrastructure
{
    public interface IInitializer
    {
        void Initialize();
    }
}
